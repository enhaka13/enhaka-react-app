import React from 'react';

const MyContext = React.createContext();

class MyProvider extends React.Component {
    constructor() {
        super();
        this.state = {
            name: 'Budianto',
            age: 17,
            height: '164 cm',
            weight: '64 kg',
            birthDate: '18 Januari 2003',
            lastStudy: 'SMA',
            hobby: 'membaca, koding, desain grafis',
            address: 'Jalan Juanda no.7, Bandung'
        }
    }

    render() {
        return (
            <MyContext.Provider value = {{
                state: this.state
            }}>
                {this.props.children}
            </MyContext.Provider>
        )
    }
}


class ContextConsumer extends React.Component {
    render() {
        return (
            <div>
                <MyContext.Consumer>
                    {(context) => (
                        <React.Fragment>
                            <p>Nama: {context.state.name}</p>
                            <p>Umur: {context.state.age}</p>
                            <p>Tinggi badan: {context.state.height}</p>
                            <p>Berat: {context.state.weight}</p>
                            <p>Tanggal lahir: {context.state.birthDate}</p>
                            <p>Pendidikan terakhir: {context.state.lastStudy}</p>
                            <p>Hobi: {context.state.hobby}</p>
                            <p>Alamat: {context.state.address}</p>
                        </React.Fragment>
                    )}
                </MyContext.Consumer>
            </div>
        )
    }
}

class Context extends React.Component {
    render() {
        return (
            <MyProvider>
                <div style = {{marginLeft: 200, marginRight: 200}}>
                    <h1 style = {{backgroundColor: "#0056b7", color: "#ffffff"}}>You're now in Context page</h1>
                    <ContextConsumer />
                </div>
            </MyProvider>
        )
    }
}

export default Context