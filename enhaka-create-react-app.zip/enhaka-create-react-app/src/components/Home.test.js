import React from 'react';
import { render } from '@testing-library/react';
import Home from './Home';

test('home', () => {
    const { getByText } = render(<Home />);
    const home = getByText(/You're now in Home page/);
    expect(home).toBeInTheDocument();
})