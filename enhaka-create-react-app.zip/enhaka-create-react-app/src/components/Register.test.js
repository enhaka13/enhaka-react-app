import React from 'react';
import { render } from '@testing-library/react';
import Register from './Register';

test('register', () => {
    const { getByText } = render(<Register />);
    const register = getByText(/You're now in Register page/);
    expect(register).toBeInTheDocument();
})