import React from 'react';

function Product (props) {
    return(
        <div>
            <h3 style = {{color: "#ffffff", backgroundColor: "#2d50b4"}}>{props.name}</h3>
            <br/>
            <p style = {{color: "#2d50b4"}}>Price: {props.price}</p>
            <p>Description: {props.description}</p>
            <hr/>
            <br/>
            <br/>
        </div>
    )
}

export default Product