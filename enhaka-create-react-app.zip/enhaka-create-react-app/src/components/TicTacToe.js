import React from 'react';
import Game from './TicTacToe/Game';
import './index.css';

function TicTacToe() {
    return (
        <div style = {{marginLeft: 200, marginRight: 200}}>
            <h1 style = {{backgroundColor: "#71bccb", color: "#ffffff"}}>Play Tic Tac Toe!</h1>
            <Game />
        </div>
    )
}

export default TicTacToe