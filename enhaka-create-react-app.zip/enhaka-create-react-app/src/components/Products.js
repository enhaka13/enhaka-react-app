import React from "react";
import productsData from "./Products/VSchoolProducts";
import Product from "./Products/ProductsMap";

const fixedProductsData = productsData.map(data => <Product key = {data.id} name = {data.name} price = {data.price} description = {data.description}/>);

function App() {
  return (
    <div style = {{marginLeft: 200, marginRight: 200}}>
        <h1 style = {{backgroundColor: "#2d6593", color: "#ffffff"}}>You're now in Products page</h1>
        {fixedProductsData}
    </div>
  )
};

export default App