import React from 'react';
import { render } from '@testing-library/react';
import Player from './Player';

test('player', () => {
    const { getByText } = render(<Player />);
    const player = getByText(/You're now in Lifting State Up page/);
    expect(player).toBeInTheDocument();
})