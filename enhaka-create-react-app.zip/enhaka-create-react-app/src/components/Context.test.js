import React from 'react';
import { render } from '@testing-library/react';
import Context from './Context';

test('context', () => {
    const { getByText } = render(<Context />);
    const context = getByText(/You're now in Context page/);
    expect(context).toBeInTheDocument();
})
