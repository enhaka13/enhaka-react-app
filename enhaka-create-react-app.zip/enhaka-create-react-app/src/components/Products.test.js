import React from 'react';
import { render } from '@testing-library/react';
import Products from './Products';

test('products', () => {
    const { getByText } = render(<Products />);
    const products = getByText(/You're now in Products page/);
    expect(products).toBeInTheDocument();
})