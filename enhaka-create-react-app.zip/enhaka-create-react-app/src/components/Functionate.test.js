import React from 'react';
import { render } from '@testing-library/react';
import Functionate from './Functionate';

test('functionate', () => {
    const { getByText } = render(<Functionate />);
    const functionate = getByText(/You're now in Functionate page/);
    expect(functionate).toBeInTheDocument();
})