import React from 'react';
import PlayerContent from './PlayerComponents/PlayerContent';
import PlayerDetails from './PlayerComponents/PlayerDetails';
import './App.css';
class App extends React.Component {
   constructor(props) {
      super(props);
      this.state = { selectedPlayer:[0,0], playerName: ''};
      this.updateSelectedPlayer = this.updateSelectedPlayer.bind(this);
   }
   updateSelectedPlayer(id, name) {
      var arr = [0, 0, 0, 0];
      arr[id] = 1;
      this.setState({
         playerName: name,
         selectedPlayer: arr
      });
   }
   render () {
      return (
         <div style = {{marginLeft: 200, marginRight: 200}}> 
            <h1 style = {{backgroundColor: "#d5467a", color: "#ffffff"}}>You're now in Lifting State Up page</h1>
            <PlayerContent active={this.state.selectedPlayer[0]}
            clickHandler={this.updateSelectedPlayer} id={0} name="Mas Arjun"/>
            <PlayerContent active={this.state.selectedPlayer[1]}
            clickHandler={this.updateSelectedPlayer} id={1} name="Mas Hilmy"/>
            <PlayerDetails name={this.state.playerName}/>
         </div>
      );
   }
}
export default App;