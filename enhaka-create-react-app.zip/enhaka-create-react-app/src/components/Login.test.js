import React from 'react';
import { render } from '@testing-library/react';
import Login from './Login';

test('login', () => {
    const { getByText } = render(<Login />);
    const login = getByText(/You're now in Login page/);
    expect(login).toBeInTheDocument();
})