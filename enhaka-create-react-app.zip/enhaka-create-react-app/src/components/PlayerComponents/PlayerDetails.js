import React, { Component } from 'react';
class PlayerDetails extends Component {
   render () {
      return (
         <div>{this.props.name}
         </div>
      );
   }
}
export default PlayerDetails;