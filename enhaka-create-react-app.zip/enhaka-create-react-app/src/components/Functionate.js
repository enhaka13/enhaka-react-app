import React, { useState } from 'react';

function Functionate() {
    const[count, setCount] = useState(0)
    
    function increment() {
        setCount(prevState => prevState + 1)
    }
    
    function decrement() {
        setCount(prevState => prevState - 1)
    }
    
    function functionate() {
        setCount(prevState => prevState ** 2 + prevState * 2 + prevState + 1)
    }
    
    function reset() {
        setCount(prevState => prevState * 0)
    }

    return (
        <div style = {{marginLeft: 200, marginRight: 200}}>
            <h1 style = {{backgroundColor: "#71cbb0", color: "#ffffff"}}>You're now in Functionate page</h1>
            <h1>{count}</h1>
            <button name = "increment" onClick = {increment}>increment</button>
            <button name = "decrement" onClick = {decrement}>decrement</button>
            <button name = "functionate" onClick = {functionate}>functionate</button>
            <button name = "reset" onClick = {reset}>reset</button>
        </div>
    )
}

export default Functionate