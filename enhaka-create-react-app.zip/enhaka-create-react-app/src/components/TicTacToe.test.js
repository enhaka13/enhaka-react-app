import React from 'react';
import { render } from '@testing-library/react';
import TicTacToe from './TicTacToe';

test('ticTacToe', () => {
    const { getByText } = render(<TicTacToe />);
    const ticTacToe = getByText(/Play Tic Tac Toe!/);
    expect(ticTacToe).toBeInTheDocument();
})