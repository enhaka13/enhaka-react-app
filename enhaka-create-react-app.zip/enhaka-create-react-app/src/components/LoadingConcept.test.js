import React from 'react';
import { render } from '@testing-library/react';
import LoadingConcept from './LoadingConcept';

test('loadingConcept', () => {
    const { getByText } = render(<LoadingConcept />);
    const loadingConcept = getByText(/Actually it's about componentDidMount/);
    expect(loadingConcept).toBeInTheDocument();
})