import React from 'react';

class LoadingConcept extends React.Component {
    constructor() {
        super();
        this.state = {
            isLoading: true,
            data: 'Your data has been updated.'
        }
    }
    
    componentDidMount() {
        setTimeout (
            this.state.isLoading ?
            this.setState({isLoading: false}):
            ''
            , 1000 
        )
    }

    render() {
        return (
            <div style = {{marginLeft: 200, marginRight: 200}}>
                <h1 style = {{backgroundColor: "#554493", color: "#ffffff"}}>You're now in Loading Concept (LifeCycle) page</h1>
                <h2>Actually it's about componentDidMount</h2>
                {
                    this.state.isLoading ?
                    'Loading..' :
                    this.state.data
                }
            </div>
        )
    }
}

export default LoadingConcept