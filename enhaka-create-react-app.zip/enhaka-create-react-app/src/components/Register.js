import React from 'react';

class Register extends React.Component {
    constructor() {
        super();
        this.state = {
            firstName: '',
            lastName: '',
            age: '',
            gender: '',
            destination: '',
            isHalal: false,
            isVegan: false,
            isLactoseFree: false
        };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    
    handleChange(event) {
        const{name, type, value, checked} = event.target;
        type === "checkbox" ?
        this.setState({ [name]: checked }):
        this.setState({ [name]: value })
    }
    
    handleSubmit(event) {
        alert (`
            Check your input data below
            
            Name: ${this.state.firstName} ${this.state.lastName}
            Age: ${this.state.age}
            Gender: ${this.state.gender}
            Destination: ${this.state.destination}
            Dietary Restriction: ${this.state.isHalal ? 'Halal' : ''},  ${this.state.isVegan ? 'Vegetarian' : ''}, ${this.state.isLactoseFree ? 'Lactose Free' : ''}
        `);
    }

    render() {
        return (
            <div style = {{marginLeft: 200, marginRight: 200}}>
                <h1 style = {{backgroundColor: "#faa74e", color: "#ffffff"}}>You're now in Register page</h1>
                <h4 style = {{color: "#faa74e"}}>Register now, access forever.</h4>
                <form onSubmit = {this.handleSubmit}>
                    <input name = "firstName" type = "text" value = {this.state.firstName} placeholder = "First Name "onChange = {this.handleChange}/><br/>
                    
                    <input name = "lastName" type = "text" value = {this.state.lastName}  placeholder = "Last Name" onChange = {this.handleChange}/><br/>
                    
                    <input name = "age" type = "number" value = {this.state.age} placeholder = "Age" onChange = {this.handleChange}/><br/>
                    
                    <input name = "gender" type = "radio" value = "male" checked = {this.state.gender === "male"} onChange = {this.handleChange}/> Male<br/>
                    
                    <input name = "gender" type = "radio" value = "female" checked = {this.state.gender === "female"} onChange = {this.handleChange}/> Female<br/>
                    
                    <select name = "destination" value = {this.state.destination} onChange = {this.handleChange}>
                        <option>--select your destination--</option>
                        <option value = "norway">Norway</option>
                        <option value = "iceland">Iceland</option>
                        <option value = "poland">Poland</option>
                        <option value = "denmark">Denmark</option>
                        <option value = "sweden">Sweden</option>
                    </select><br/>
                    
                    <input name = "isHalal" type = "checkbox" checked = {this.state.isHalal} onChange = {this.handleChange} /> Halal<br/>
                    
                    <input name = "isVegan" type = "checkbox" checked = {this.state.isVegan} onChange = {this.handleChange} /> Vegetarian<br/>
                    
                    <input name = "isLactoseFree" type = "checkbox" checked = {this.state.isLactoseFree} onChange = {this.handleChange} /> Lactose Free<br/>
                    
                    <button>submit</button>
                </form>
            </div>
        )
    }
}

export default Register