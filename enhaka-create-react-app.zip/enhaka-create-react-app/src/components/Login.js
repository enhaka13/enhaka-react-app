import React from 'react';

class Login extends React.Component {  
    constructor() {
        super();
        this.state = {
            isLoggedIn: true
        };
        this.handleClick = this.handleClick.bind(this)
    }
    
    handleClick() {
        this.state.isLoggedIn ?
        this.setState({isLoggedIn: false}):
        this.setState({isLoggedIn: true})
    }

    render() {
        return (
            <div style = {{marginLeft: 200, marginRight: 200}}>
                <h1 style = {{backgroundColor: "#7db050", color: "#ffffff"}}>You're now in Login page</h1>
                {
                    this.state.isLoggedIn ?
                    <h3 style = {{color: "#7db050"}}>You are logged in</h3>:
                    <h3 style = {{color: "#7db050"}}>You are logged out</h3>
                }
                <button onClick = {this.handleClick}>
                    {
                        this.state.isLoggedIn ?
                        "log out":
                        "log in"
                    }
                </button>
            </div>
        )
    }
}

export default Login
