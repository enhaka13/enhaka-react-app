import React from 'react';
import { Link, NavLink } from 'react-router-dom';

function Navbar() {
    return (
        <nav>
            <div>
                <h1><Link to = "/">React Showcase</Link></h1>
                <ul>
                    <li><Link to = "/">Home</Link></li>
                    <li><Link to = "/register">Register</Link></li>
                    <li><Link to = "/login">Login</Link></li>
                    <li><Link to = "/functionate">Functionate</Link></li>
                    <li><Link to = "/ticTacToe">Tic Tac Toe</Link></li>
                    <li><Link to = "/products">Products</Link></li>
                    <li><Link to = "/loadingConcept">Loading Concept</Link></li>
                    <li><Link to = "/player">Player</Link></li>
                    <li><Link to = "/context">Context</Link></li>
                </ul>
            </div>
        </nav>
    )
}

export default Navbar