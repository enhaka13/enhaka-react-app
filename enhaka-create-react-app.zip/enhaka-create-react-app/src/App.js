import React from 'react';
import Navbar from './Navbar';
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import Functionate from './components/Functionate';
import TicTacToe from './components/TicTacToe';
import Products from './components/Products';
import LoadingConcept from './components/LoadingConcept';
import Player from './components/Player';
import Context from './components/Context';
import { BrowserRouter, Route } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <BrowserRouter>
        <div className = "App">
          <Navbar /> <br/>
          <Route exact path = '/' component = {Home} />
          <Route path = '/register' component = {Register} />
          <Route path = '/login' component = {Login} />
          <Route path = '/functionate' component = {Functionate} />
          <Route path = '/ticTacToe' component = {TicTacToe} />
          <Route path = '/products' component = {Products} />
          <Route path = '/loadingConcept' component = {LoadingConcept} />
          <Route path = '/player' component = {Player} />
          <Route path = '/context' component = {Context} />
        </div>
    </BrowserRouter>
  )
}

export default App;
