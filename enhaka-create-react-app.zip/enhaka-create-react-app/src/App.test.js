import React from 'react';
import { render } from '@testing-library/react';
import App from './App';

test('2 + 3 = 5', () => {
  expect(2 + 3).toBe(5)
})

test('object equality', () => {
  const objek = {pertama: 1};
  objek['kedua'] = 2;
  objek['ketiga'] = 3;
  expect(objek).toEqual({
    pertama: 1,
    kedua: 2,
    ketiga: 3
  });
  expect(objek).toBeDefined();

  let mantap;
  expect(mantap).toBeUndefined();

  let kosong = null;
  expect(kosong).toBeNull();
  expect(kosong).toBeDefined();

  let salah = false;
  expect(salah).toBeFalsy();

  let benar = true;
  expect(benar).toBeTruthy();

  let lima = 5;
  let empat = 4;
  expect(lima).toBeGreaterThan(empat);
  expect(lima).toBeGreaterThanOrEqual(empat);
  expect(empat).toBeLessThan(lima);

  let string = 'ini string';
  expect(string).not.toMatch(/a/); //arti nya memang ga ada huruf a di variabel string
  expect(string).toMatch(/i/);

  let array = [1, 2, 3];
  expect(array).toContain(2, 3); //artinya betul bahwa array ini mengandung data type number yaitu 2 dan 3
})